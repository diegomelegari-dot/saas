import { useState, useEffect } from "react"
import { initAuth, isLoggedIn, logout } from "./auth"
import LoginPage from "./pages/LoginPage"
import MainApp from "./pages/MainApp"

export default function App() {
  const [loggedIn, setLoggedIn] = useState(false)

  useEffect(() => {
    initAuth()
    setLoggedIn(isLoggedIn())
  }, [])

  function handleLogin() { setLoggedIn(true) }

  function handleLogout() {
    logout()
    setLoggedIn(false)
  }

  if (!loggedIn) return <LoginPage onLogin={handleLogin} />
  return <MainApp onLogout={handleLogout} />
}
