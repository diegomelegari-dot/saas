export interface Expense {
  id: string
  data: string
  categoria: string
  descricao: string
  valor: number
  tipo: "Despesa" | "Receita"
}

export interface SheetsConfig {
  scriptUrl: string
}

export type CategoryTotal = {
  name: string
  total: number
  color: string
}
