import type { Expense } from "../types"

export async function fetchExpenses(scriptUrl: string): Promise<Expense[]> {
  const res = await fetch(`${scriptUrl}?action=getAll`)
  if (!res.ok) throw new Error("Falha ao buscar dados")
  const rows: string[][] = await res.json()
  // skip header row
  return rows.slice(1).map((row, i) => ({
    id: `row-${i}`,
    data: row[0] ?? "",
    categoria: row[1] ?? "",
    descricao: row[2] ?? "",
    valor: parseFloat(row[3]) || 0,
    tipo: (row[4] === "Receita" ? "Receita" : "Despesa") as "Despesa" | "Receita",
  }))
}

export async function appendExpense(
  scriptUrl: string,
  expense: Omit<Expense, "id">
): Promise<void> {
  const res = await fetch(scriptUrl, {
    method: "POST",
    body: JSON.stringify({
      action: "append",
      data: expense.data,
      categoria: expense.categoria,
      descricao: expense.descricao,
      valor: expense.valor,
      tipo: expense.tipo,
    }),
  })
  if (!res.ok) throw new Error("Falha ao salvar gasto")
}
