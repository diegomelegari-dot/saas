export interface Category {
  id: string
  name: string
  color: string
  emoji: string
}

const STORAGE_KEY = "finances_categories"

export const DEFAULT_CATEGORIES: Category[] = [
  { id: "alimentacao", name: "Alimentação", color: "#10b981", emoji: "🍽" },
  { id: "transporte", name: "Transporte", color: "#6366f1", emoji: "🚗" },
  { id: "moradia", name: "Moradia", color: "#f59e0b", emoji: "🏠" },
  { id: "saude", name: "Saúde", color: "#ef4444", emoji: "💊" },
  { id: "educacao", name: "Educação", color: "#3b82f6", emoji: "📚" },
  { id: "lazer", name: "Lazer", color: "#ec4899", emoji: "🎬" },
  { id: "vestuario", name: "Vestuário", color: "#8b5cf6", emoji: "👔" },
  { id: "farmacia", name: "Farmácia", color: "#f97316", emoji: "💉" },
  { id: "aluguel", name: "Aluguel", color: "#eab308", emoji: "🔑" },
  { id: "outros", name: "Outros", color: "#64748b", emoji: "📦" },
]

export function loadCategories(): Category[] {
  try {
    const stored = localStorage.getItem(STORAGE_KEY)
    if (stored) return JSON.parse(stored)
  } catch {
    // ignore
  }
  localStorage.setItem(STORAGE_KEY, JSON.stringify(DEFAULT_CATEGORIES))
  return DEFAULT_CATEGORIES
}

export function saveCategories(cats: Category[]) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(cats))
}

export const COLOR_OPTIONS = [
  "#10b981", "#6366f1", "#f59e0b", "#ef4444", "#3b82f6",
  "#ec4899", "#8b5cf6", "#f97316", "#eab308", "#64748b",
  "#06b6d4", "#84cc16", "#a855f7", "#14b8a6", "#fb7185",
]

export const EMOJI_OPTIONS = [
  "🍽","🚗","🏠","💊","📚","🎬","👔","💉","🔑","📦",
  "✈️","🛒","🎮","🏋️","🐾","💻","📱","🎵","🍺","🎁",
  "💈","⚡","🌊","🏥","🎓","💰","🛵","🧾","🏦","🍕",
]
