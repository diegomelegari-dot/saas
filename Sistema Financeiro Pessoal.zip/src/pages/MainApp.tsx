import { useState, useEffect, useMemo } from "react"
import {
  PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis,
  Tooltip, ResponsiveContainer, Legend,
} from "recharts"
import type { Expense, SheetsConfig } from "../types"
import { fetchExpenses, appendExpense } from "../api/googleSheets"
import { logout, getUser, changeCredentials } from "../auth"
import { loadCategories, saveCategories, COLOR_OPTIONS, EMOJI_OPTIONS } from "../categories"
import type { Category } from "../categories"

// ── helpers ────────────────────────────────────────────────────────────────────
function fmt(v: number) {
  return v.toLocaleString("pt-BR", { style: "currency", currency: "BRL" })
}
function fmtDate(d: string) {
  if (!d) return ""
  const [y, m, dd] = d.split("-")
  return `${dd}/${m}/${y}`
}
function todayIso() { return new Date().toISOString().split("T")[0] }

function monthStart(year: number, month: number) {
  return `${year}-${String(month).padStart(2, "0")}-01`
}
function monthEnd(year: number, month: number) {
  const last = new Date(year, month, 0).getDate()
  return `${year}-${String(month).padStart(2, "0")}-${last}`
}

const MONTH_NAMES = ["Jan","Fev","Mar","Abr","Mai","Jun","Jul","Ago","Set","Out","Nov","Dez"]

const SAMPLE_EXPENSES: Expense[] = [
  { id: "1", data: "2026-07-01", categoria: "Alimentação", descricao: "Supermercado", valor: 342.5, tipo: "Despesa" },
  { id: "2", data: "2026-07-02", categoria: "Transporte", descricao: "Gasolina", valor: 180.0, tipo: "Despesa" },
  { id: "3", data: "2026-07-03", categoria: "Aluguel", descricao: "Aluguel julho", valor: 1400.0, tipo: "Despesa" },
  { id: "4", data: "2026-07-05", categoria: "Farmácia", descricao: "Medicamento", valor: 89.9, tipo: "Despesa" },
  { id: "5", data: "2026-07-06", categoria: "Lazer", descricao: "Cinema", valor: 54.0, tipo: "Despesa" },
  { id: "6", data: "2026-07-07", categoria: "Educação", descricao: "Curso online", valor: 129.0, tipo: "Despesa" },
  { id: "7", data: "2026-07-08", categoria: "Alimentação", descricao: "Restaurante", valor: 78.0, tipo: "Despesa" },
  { id: "8", data: "2026-07-10", categoria: "Transporte", descricao: "Uber", valor: 42.3, tipo: "Despesa" },
  { id: "9", data: "2026-07-12", categoria: "Vestuário", descricao: "Tênis", valor: 250.0, tipo: "Despesa" },
  { id: "10", data: "2026-07-15", categoria: "Receita", descricao: "Salário", valor: 5500.0, tipo: "Receita" },
  { id: "11", data: "2026-07-16", categoria: "Alimentação", descricao: "iFood", valor: 65.0, tipo: "Despesa" },
  { id: "12", data: "2026-07-18", categoria: "Farmácia", descricao: "Consulta médica", valor: 200.0, tipo: "Despesa" },
  { id: "13", data: "2026-06-15", categoria: "Alimentação", descricao: "Supermercado junho", valor: 290.0, tipo: "Despesa" },
  { id: "14", data: "2026-06-15", categoria: "Receita", descricao: "Salário junho", valor: 5500.0, tipo: "Receita" },
]

// ── Period Selector ────────────────────────────────────────────────────────────
interface Period { from: string; to: string }

function PeriodSelector({ period, onChange }: { period: Period; onChange: (p: Period) => void }) {
  const [editing, setEditing] = useState(false)
  const [draft, setDraft] = useState(period)

  const fromDate = new Date(period.from + "T00:00:00")
  const toDate = new Date(period.to + "T00:00:00")

  function prevMonth() {
    const d = new Date(fromDate)
    d.setMonth(d.getMonth() - 1)
    onChange({ from: monthStart(d.getFullYear(), d.getMonth() + 1), to: monthEnd(d.getFullYear(), d.getMonth() + 1) })
  }
  function nextMonth() {
    const d = new Date(fromDate)
    d.setMonth(d.getMonth() + 1)
    onChange({ from: monthStart(d.getFullYear(), d.getMonth() + 1), to: monthEnd(d.getFullYear(), d.getMonth() + 1) })
  }
  function applyDraft() {
    if (draft.from && draft.to && draft.from <= draft.to) {
      onChange(draft)
      setEditing(false)
    }
  }
  function openEdit() { setDraft(period); setEditing(true) }

  const label = `${MONTH_NAMES[fromDate.getMonth()]} ${fromDate.getFullYear()}`

  return (
    <div className="relative flex items-center gap-1">
      <button onClick={prevMonth} className="w-7 h-7 flex items-center justify-center rounded-lg hover:bg-white/10 transition-colors" style={{ border: "1px solid var(--border)" }}>
        <svg width="13" height="13" viewBox="0 0 13 13" fill="none"><path d="M8 10L4.5 6.5 8 3" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round"/></svg>
      </button>

      <button
        onClick={openEdit}
        className="flex items-center gap-2 px-3 py-1.5 rounded-xl text-sm font-medium transition-colors hover:bg-white/10"
        style={{ border: "1px solid var(--border)" }}
      >
        <svg width="13" height="13" viewBox="0 0 13 13" fill="none"><rect x="1.5" y="2.5" width="10" height="9" rx="1.5" stroke="currentColor" strokeWidth="1.2"/><path d="M4 1v3M9 1v3M1.5 6h10" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round"/></svg>
        <span>{label}</span>
        <span className="text-xs" style={{ color: "var(--muted-foreground)" }}>
          {fmtDate(period.from)} – {fmtDate(period.to)}
        </span>
      </button>

      <button onClick={nextMonth} className="w-7 h-7 flex items-center justify-center rounded-lg hover:bg-white/10 transition-colors" style={{ border: "1px solid var(--border)" }}>
        <svg width="13" height="13" viewBox="0 0 13 13" fill="none"><path d="M5 3l3.5 3.5L5 10" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round"/></svg>
      </button>

      {editing && (
        <div className="absolute top-10 left-0 z-50 rounded-2xl p-4 flex flex-col gap-3 w-72" style={{ background: "var(--card)", border: "1px solid var(--border)", boxShadow: "0 16px 48px rgba(0,0,0,0.4)" }}>
          <div className="flex items-center justify-between">
            <p className="text-sm font-semibold">Período personalizado</p>
            <button onClick={() => setEditing(false)} className="w-6 h-6 flex items-center justify-center rounded-lg hover:bg-white/10">
              <svg width="12" height="12" viewBox="0 0 12 12" fill="none"><path d="M10 2L2 10M2 2l8 8" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round"/></svg>
            </button>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <div className="flex flex-col gap-1">
              <label className="text-xs" style={{ color: "var(--muted-foreground)" }}>De</label>
              <input type="date" value={draft.from} onChange={(e) => setDraft((d) => ({ ...d, from: e.target.value }))}
                className="rounded-xl px-3 py-2 text-xs outline-none" style={{ background: "var(--muted)", border: "1px solid var(--border)", color: "var(--foreground)" }} />
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-xs" style={{ color: "var(--muted-foreground)" }}>Até</label>
              <input type="date" value={draft.to} onChange={(e) => setDraft((d) => ({ ...d, to: e.target.value }))}
                className="rounded-xl px-3 py-2 text-xs outline-none" style={{ background: "var(--muted)", border: "1px solid var(--border)", color: "var(--foreground)" }} />
            </div>
          </div>
          <div className="flex gap-2 text-xs">
            {["Este mês","Mês passado","Este ano"].map((l) => (
              <button key={l} onClick={() => {
                const now = new Date()
                if (l === "Este mês") setDraft({ from: monthStart(now.getFullYear(), now.getMonth() + 1), to: monthEnd(now.getFullYear(), now.getMonth() + 1) })
                else if (l === "Mês passado") { const pm = new Date(now.getFullYear(), now.getMonth() - 1, 1); setDraft({ from: monthStart(pm.getFullYear(), pm.getMonth() + 1), to: monthEnd(pm.getFullYear(), pm.getMonth() + 1) }) }
                else setDraft({ from: `${now.getFullYear()}-01-01`, to: `${now.getFullYear()}-12-31` })
              }} className="px-2 py-1 rounded-lg" style={{ background: "var(--muted)", border: "1px solid var(--border)" }}>
                {l}
              </button>
            ))}
          </div>
          <button onClick={applyDraft} className="w-full py-2 rounded-xl text-sm font-semibold" style={{ background: "var(--primary)", color: "#fff" }}>
            Aplicar
          </button>
        </div>
      )}
    </div>
  )
}

// ── Category Manager Modal ─────────────────────────────────────────────────────
function CategoryManager({ onClose }: { onClose: () => void }) {
  const [cats, setCats] = useState<Category[]>(loadCategories)
  const [editing, setEditing] = useState<Category | null>(null)
  const [isNew, setIsNew] = useState(false)
  const [draft, setDraft] = useState<Partial<Category>>({})
  const [emojiSearch, setEmojiSearch] = useState("")

  function startNew() {
    setDraft({ name: "", color: COLOR_OPTIONS[0], emoji: "📦" })
    setEditing(null)
    setIsNew(true)
  }
  function startEdit(cat: Category) {
    setDraft({ ...cat })
    setEditing(cat)
    setIsNew(false)
  }
  function cancel() { setEditing(null); setIsNew(false); setDraft({}) }
  function save() {
    if (!draft.name?.trim()) return
    const id = draft.id ?? `cat-${Date.now()}`
    const updated = isNew
      ? [...cats, { id, name: draft.name!, color: draft.color!, emoji: draft.emoji! }]
      : cats.map((c) => (c.id === editing?.id ? { ...c, ...draft } as Category : c))
    setCats(updated)
    saveCategories(updated)
    cancel()
  }
  function remove(id: string) {
    const updated = cats.filter((c) => c.id !== id)
    setCats(updated)
    saveCategories(updated)
  }

  const filteredEmojis = EMOJI_OPTIONS.filter((e) => !emojiSearch || e.includes(emojiSearch))

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" style={{ background: "rgba(0,0,0,0.7)" }}>
      <div className="w-full max-w-lg rounded-2xl p-6 flex flex-col gap-5 max-h-[90vh] overflow-y-auto" style={{ background: "var(--card)", border: "1px solid var(--border)" }}>
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold">Gerenciar Categorias</h2>
          <button onClick={onClose} className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-white/10">
            <svg width="15" height="15" viewBox="0 0 15 15" fill="none"><path d="M12 3L3 12M3 3l9 9" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/></svg>
          </button>
        </div>

        {/* Form */}
        {(isNew || editing) && (
          <div className="rounded-xl p-4 flex flex-col gap-3" style={{ background: "var(--muted)", border: "1px solid var(--border)" }}>
            <p className="text-sm font-semibold">{isNew ? "Nova categoria" : "Editar categoria"}</p>
            <div className="flex gap-3">
              <div className="flex flex-col gap-1 flex-1">
                <label className="text-xs" style={{ color: "var(--muted-foreground)" }}>Nome</label>
                <input
                  type="text"
                  value={draft.name ?? ""}
                  onChange={(e) => setDraft((d) => ({ ...d, name: e.target.value }))}
                  placeholder="Ex: Pets, Streaming..."
                  className="rounded-xl px-3 py-2 text-sm outline-none"
                  style={{ background: "var(--card)", border: "1px solid var(--border)", color: "var(--foreground)" }}
                />
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <label className="text-xs" style={{ color: "var(--muted-foreground)" }}>Cor</label>
              <div className="flex flex-wrap gap-2">
                {COLOR_OPTIONS.map((c) => (
                  <button key={c} onClick={() => setDraft((d) => ({ ...d, color: c }))}
                    className="w-7 h-7 rounded-lg transition-transform hover:scale-110"
                    style={{ background: c, outline: draft.color === c ? `2px solid #fff` : "none", outlineOffset: 2 }}
                  />
                ))}
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <label className="text-xs" style={{ color: "var(--muted-foreground)" }}>Emoji</label>
              <div className="flex flex-wrap gap-1.5 max-h-20 overflow-y-auto">
                {EMOJI_OPTIONS.map((e) => (
                  <button key={e} onClick={() => setDraft((d) => ({ ...d, emoji: e }))}
                    className="w-8 h-8 text-lg rounded-lg transition-all hover:bg-white/10"
                    style={{ background: draft.emoji === e ? "rgba(255,255,255,0.15)" : "transparent" }}
                  >{e}</button>
                ))}
              </div>
            </div>

            {/* Preview */}
            <div className="flex items-center gap-2 p-3 rounded-xl" style={{ background: "var(--card)" }}>
              <span className="text-xs" style={{ color: "var(--muted-foreground)" }}>Pré-visualização:</span>
              <span className="inline-flex items-center gap-1.5 text-xs px-2.5 py-1 rounded-lg" style={{ background: `${draft.color}22`, color: draft.color }}>
                {draft.emoji} {draft.name || "Categoria"}
              </span>
            </div>

            <div className="flex gap-2">
              <button onClick={cancel} className="flex-1 py-2 rounded-xl text-sm" style={{ border: "1px solid var(--border)" }}>Cancelar</button>
              <button onClick={save} className="flex-1 py-2 rounded-xl text-sm font-semibold" style={{ background: "var(--primary)", color: "#fff" }}>Salvar</button>
            </div>
          </div>
        )}

        {/* List */}
        <div className="flex flex-col gap-2">
          {cats.map((cat) => (
            <div key={cat.id} className="flex items-center gap-3 px-3 py-2.5 rounded-xl" style={{ border: "1px solid var(--border)" }}>
              <span className="text-xl">{cat.emoji}</span>
              <span className="flex-1 text-sm font-medium">{cat.name}</span>
              <div className="w-3.5 h-3.5 rounded-full shrink-0" style={{ background: cat.color }} />
              <button onClick={() => startEdit(cat)} className="w-7 h-7 flex items-center justify-center rounded-lg hover:bg-white/10 transition-colors">
                <svg width="13" height="13" viewBox="0 0 13 13" fill="none"><path d="M9 2l2 2-7 7H2V9l7-7z" stroke="currentColor" strokeWidth="1.2" strokeLinejoin="round"/></svg>
              </button>
              <button onClick={() => remove(cat.id)} className="w-7 h-7 flex items-center justify-center rounded-lg hover:bg-red-500/20 transition-colors" style={{ color: "#f87171" }}>
                <svg width="13" height="13" viewBox="0 0 13 13" fill="none"><path d="M2 3.5h9M5 3.5V2h3v1.5M5.5 6v4M7.5 6v4M3 3.5l.5 7.5h6L10 3.5" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round"/></svg>
              </button>
            </div>
          ))}
        </div>

        <button onClick={startNew} className="flex items-center justify-center gap-2 w-full py-2.5 rounded-xl text-sm font-medium transition-colors hover:bg-white/10" style={{ border: "1px dashed var(--border)" }}>
          <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M7 2v10M2 7h10" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"/></svg>
          Nova categoria
        </button>
      </div>
    </div>
  )
}

// ── Profile Modal ─────────────────────────────────────────────────────────────
function ProfileModal({ onClose }: { onClose: () => void }) {
  const user = getUser()
  const [email, setEmail] = useState(user.email)
  const [currentPass, setCurrentPass] = useState("")
  const [newPass, setNewPass] = useState("")
  const [confirmPass, setConfirmPass] = useState("")
  const [error, setError] = useState("")
  const [success, setSuccess] = useState("")

  function handleSave(e: React.FormEvent) {
    e.preventDefault()
    setError(""); setSuccess("")
    if (currentPass && currentPass !== user.password) { setError("Senha atual incorreta."); return }
    if (newPass && newPass !== confirmPass) { setError("As senhas não conferem."); return }
    if (newPass && newPass.length < 6) { setError("A nova senha deve ter ao menos 6 caracteres."); return }
    changeCredentials(email.trim() || user.email, newPass || user.password)
    setSuccess("Dados atualizados com sucesso!")
    setCurrentPass(""); setNewPass(""); setConfirmPass("")
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" style={{ background: "rgba(0,0,0,0.7)" }}>
      <div className="w-full max-w-md rounded-2xl p-6" style={{ background: "var(--card)", border: "1px solid var(--border)" }}>
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-lg font-semibold">Minha Conta</h2>
          <button onClick={onClose} className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-white/10">
            <svg width="15" height="15" viewBox="0 0 15 15" fill="none"><path d="M12 3L3 12M3 3l9 9" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/></svg>
          </button>
        </div>

        <form onSubmit={handleSave} className="flex flex-col gap-4">
          <div className="flex items-center gap-4 p-4 rounded-xl" style={{ background: "var(--muted)" }}>
            <div className="w-12 h-12 rounded-full flex items-center justify-center text-lg font-bold" style={{ background: "linear-gradient(135deg, #10b981, #6366f1)" }}>
              {user.email[0].toUpperCase()}
            </div>
            <div>
              <p className="font-medium text-sm">{user.email}</p>
              <p className="text-xs mt-0.5" style={{ color: "var(--muted-foreground)" }}>Conta pessoal</p>
            </div>
          </div>

          <p className="text-xs font-semibold uppercase tracking-wider" style={{ color: "var(--muted-foreground)" }}>Alterar e-mail</p>
          <div className="flex flex-col gap-1">
            <label className="text-xs" style={{ color: "var(--muted-foreground)" }}>Novo e-mail</label>
            <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder={user.email}
              className="rounded-xl px-3 py-2.5 text-sm outline-none" style={{ background: "var(--muted)", border: "1px solid var(--border)", color: "var(--foreground)" }}
              onFocus={(e) => e.currentTarget.style.borderColor = "var(--primary)"}
              onBlur={(e) => e.currentTarget.style.borderColor = "var(--border)"} />
          </div>

          <p className="text-xs font-semibold uppercase tracking-wider mt-1" style={{ color: "var(--muted-foreground)" }}>Alterar senha</p>
          {[["Senha atual", currentPass, setCurrentPass], ["Nova senha", newPass, setNewPass], ["Confirmar nova senha", confirmPass, setConfirmPass]].map(([label, val, set]) => (
            <div key={label as string} className="flex flex-col gap-1">
              <label className="text-xs" style={{ color: "var(--muted-foreground)" }}>{label as string}</label>
              <input type="password" value={val as string} onChange={(e) => (set as (v: string) => void)(e.target.value)} placeholder="••••••••"
                className="rounded-xl px-3 py-2.5 text-sm outline-none" style={{ background: "var(--muted)", border: "1px solid var(--border)", color: "var(--foreground)" }}
                onFocus={(e) => e.currentTarget.style.borderColor = "var(--primary)"}
                onBlur={(e) => e.currentTarget.style.borderColor = "var(--border)"} />
            </div>
          ))}

          {error && <p className="text-xs" style={{ color: "#f87171" }}>{error}</p>}
          {success && <p className="text-xs" style={{ color: "#34d399" }}>{success}</p>}

          <button type="submit" className="w-full py-2.5 rounded-xl text-sm font-semibold" style={{ background: "var(--primary)", color: "#fff" }}>
            Salvar alterações
          </button>
        </form>
      </div>
    </div>
  )
}

// ── Add Expense Modal ─────────────────────────────────────────────────────────
function AddExpenseModal({ onClose, onSave, categories }: {
  onClose: () => void
  onSave: (e: Omit<Expense, "id">) => Promise<void>
  categories: Category[]
}) {
  const today = todayIso()
  const [form, setForm] = useState({ data: today, categoria: categories[0]?.name ?? "Outros", descricao: "", valor: "", tipo: "Despesa" as "Despesa" | "Receita" })
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState("")

  async function handleSubmit(ev: React.FormEvent) {
    ev.preventDefault()
    if (!form.descricao.trim() || !form.valor) { setError("Preencha todos os campos."); return }
    setSaving(true)
    try {
      await onSave({ ...form, valor: parseFloat(form.valor), categoria: form.tipo === "Receita" ? "Receita" : form.categoria })
      onClose()
    } catch {
      setError("Erro ao salvar. Verifique a configuração do Google Sheets.")
    } finally { setSaving(false) }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" style={{ background: "rgba(0,0,0,0.7)" }}>
      <div className="w-full max-w-md rounded-2xl p-6" style={{ background: "var(--card)", border: "1px solid var(--border)" }}>
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-lg font-semibold">Lançar Gasto</h2>
          <button onClick={onClose} className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-white/10">
            <svg width="15" height="15" viewBox="0 0 15 15" fill="none"><path d="M12 3L3 12M3 3l9 9" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/></svg>
          </button>
        </div>
        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          <div className="flex rounded-xl overflow-hidden" style={{ border: "1px solid var(--border)" }}>
            {(["Despesa","Receita"] as const).map((t) => (
              <button key={t} type="button" onClick={() => setForm((f) => ({ ...f, tipo: t }))}
                className="flex-1 py-2 text-sm font-medium transition-all"
                style={{ background: form.tipo === t ? (t === "Despesa" ? "#ef4444" : "#10b981") : "transparent", color: form.tipo === t ? "#fff" : "var(--muted-foreground)" }}>
                {t}
              </button>
            ))}
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="flex flex-col gap-1">
              <label className="text-xs" style={{ color: "var(--muted-foreground)" }}>Data</label>
              <input type="date" value={form.data} onChange={(e) => setForm((f) => ({ ...f, data: e.target.value }))}
                className="rounded-xl px-3 py-2 text-sm outline-none"
                style={{ background: "var(--muted)", border: "1px solid var(--border)", color: "var(--foreground)" }} />
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-xs" style={{ color: "var(--muted-foreground)" }}>Valor (R$)</label>
              <input type="number" min="0" step="0.01" placeholder="0,00" value={form.valor} onChange={(e) => setForm((f) => ({ ...f, valor: e.target.value }))}
                className="rounded-xl px-3 py-2 text-sm mono outline-none"
                style={{ background: "var(--muted)", border: "1px solid var(--border)", color: "var(--foreground)" }} />
            </div>
          </div>
          {form.tipo === "Despesa" && (
            <div className="flex flex-col gap-1">
              <label className="text-xs" style={{ color: "var(--muted-foreground)" }}>Categoria</label>
              <select value={form.categoria} onChange={(e) => setForm((f) => ({ ...f, categoria: e.target.value }))}
                className="rounded-xl px-3 py-2 text-sm outline-none"
                style={{ background: "var(--muted)", border: "1px solid var(--border)", color: "var(--foreground)" }}>
                {categories.map((c) => <option key={c.id}>{c.name}</option>)}
              </select>
            </div>
          )}
          <div className="flex flex-col gap-1">
            <label className="text-xs" style={{ color: "var(--muted-foreground)" }}>Descrição</label>
            <input type="text" placeholder="Ex: Supermercado, Gasolina..." value={form.descricao} onChange={(e) => setForm((f) => ({ ...f, descricao: e.target.value }))}
              className="rounded-xl px-3 py-2 text-sm outline-none"
              style={{ background: "var(--muted)", border: "1px solid var(--border)", color: "var(--foreground)" }} />
          </div>
          {error && <p className="text-xs" style={{ color: "#ef4444" }}>{error}</p>}
          <button type="submit" disabled={saving} className="w-full py-2.5 rounded-xl text-sm font-semibold"
            style={{ background: form.tipo === "Despesa" ? "#ef4444" : "#10b981", color: "#fff", opacity: saving ? 0.7 : 1 }}>
            {saving ? "Salvando..." : "Salvar"}
          </button>
        </form>
      </div>
    </div>
  )
}

// ── Settings Modal ─────────────────────────────────────────────────────────────
function SettingsModal({ config, onSave, onClose }: { config: SheetsConfig; onSave: (c: SheetsConfig) => void; onClose: () => void }) {
  const [url, setUrl] = useState(config.scriptUrl)
  const script = `function doGet(e) {
  var sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName("Gastos");
  var data = sheet.getDataRange().getValues();
  return ContentService.createTextOutput(JSON.stringify(data))
    .setMimeType(ContentService.MimeType.JSON);
}
function doPost(e) {
  var sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName("Gastos");
  var d = JSON.parse(e.postData.contents);
  sheet.appendRow([d.data, d.categoria, d.descricao, d.valor, d.tipo]);
  return ContentService.createTextOutput(JSON.stringify({ok:true}))
    .setMimeType(ContentService.MimeType.JSON);
}`
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" style={{ background: "rgba(0,0,0,0.7)" }}>
      <div className="w-full max-w-lg rounded-2xl p-6 max-h-screen overflow-y-auto" style={{ background: "var(--card)", border: "1px solid var(--border)" }}>
        <div className="flex items-center justify-between mb-5">
          <h2 className="text-lg font-semibold">Configurar Google Sheets</h2>
          <button onClick={onClose} className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-white/10">
            <svg width="15" height="15" viewBox="0 0 15 15" fill="none"><path d="M12 3L3 12M3 3l9 9" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/></svg>
          </button>
        </div>
        <div className="flex flex-col gap-4">
          <div className="rounded-xl p-4 text-sm" style={{ background: "rgba(99,102,241,0.1)", border: "1px solid rgba(99,102,241,0.3)" }}>
            <p className="font-medium mb-2" style={{ color: "#a5b4fc" }}>Como configurar:</p>
            <ol className="flex flex-col gap-1.5 text-xs" style={{ color: "var(--muted-foreground)" }}>
              <li>1. Crie uma planilha no Google Sheets com a aba <span className="mono font-medium" style={{ color: "#a5b4fc" }}>Gastos</span></li>
              <li>2. Linha 1: <span className="mono text-xs" style={{ color: "#a5b4fc" }}>Data | Categoria | Descrição | Valor | Tipo</span></li>
              <li>3. Extensões → Apps Script → cole o código abaixo</li>
              <li>4. Publicar → Implantar como Web App → acesso: Qualquer pessoa</li>
              <li>5. Cole a URL da Web App abaixo</li>
            </ol>
          </div>
          <pre className="rounded-xl p-3 text-xs overflow-x-auto mono" style={{ background: "#0d1117", border: "1px solid var(--border)", color: "#7ee787", whiteSpace: "pre-wrap", wordBreak: "break-all" }}>{script}</pre>
          <div className="flex flex-col gap-1">
            <label className="text-xs font-medium" style={{ color: "var(--muted-foreground)" }}>URL da Web App</label>
            <input type="url" placeholder="https://script.google.com/macros/s/..." value={url} onChange={(e) => setUrl(e.target.value)}
              className="rounded-xl px-3 py-2 text-sm outline-none" style={{ background: "var(--muted)", border: "1px solid var(--border)", color: "var(--foreground)" }} />
          </div>
          <div className="flex gap-3">
            <button onClick={onClose} className="flex-1 py-2.5 rounded-xl text-sm font-medium hover:bg-white/10" style={{ border: "1px solid var(--border)" }}>Cancelar</button>
            <button onClick={() => { onSave({ scriptUrl: url }); onClose() }} className="flex-1 py-2.5 rounded-xl text-sm font-semibold" style={{ background: "var(--primary)", color: "#fff" }}>Salvar</button>
          </div>
        </div>
      </div>
    </div>
  )
}

// ── Summary Card ──────────────────────────────────────────────────────────────
function SummaryCard({ label, value, sub, color, icon }: { label: string; value: string; sub?: string; color: string; icon: React.ReactNode }) {
  return (
    <div className="rounded-2xl p-5 flex flex-col gap-3" style={{ background: "var(--card)", border: "1px solid var(--border)" }}>
      <div className="flex items-center justify-between">
        <span className="text-xs font-medium uppercase tracking-wider" style={{ color: "var(--muted-foreground)" }}>{label}</span>
        <div className="w-8 h-8 rounded-xl flex items-center justify-center" style={{ background: `${color}22`, color }}>
          {icon}
        </div>
      </div>
      <div>
        <p className="text-2xl font-bold mono" style={{ color }}>{value}</p>
        {sub && <p className="text-xs mt-1" style={{ color: "var(--muted-foreground)" }}>{sub}</p>}
      </div>
    </div>
  )
}

function CustomTooltip({ active, payload, label }: { active?: boolean; payload?: { value: number; name: string }[]; label?: string }) {
  if (!active || !payload?.length) return null
  return (
    <div className="rounded-xl px-3 py-2 text-sm" style={{ background: "#1f2937", border: "1px solid var(--border)" }}>
      {label && <p className="text-xs mb-1" style={{ color: "var(--muted-foreground)" }}>{label}</p>}
      {payload.map((p, i) => <p key={i} className="mono font-medium">{fmt(p.value)}</p>)}
    </div>
  )
}

// ── Main App ──────────────────────────────────────────────────────────────────
export default function MainApp({ onLogout }: { onLogout: () => void }) {
  const now = new Date()
  const [period, setPeriod] = useState<{ from: string; to: string }>({
    from: monthStart(now.getFullYear(), now.getMonth() + 1),
    to: monthEnd(now.getFullYear(), now.getMonth() + 1),
  })
  const [expenses, setExpenses] = useState<Expense[]>(SAMPLE_EXPENSES)
  const [categories, setCategories] = useState<Category[]>(loadCategories)
  const [config, setConfig] = useState<SheetsConfig>(() => {
    try { return JSON.parse(localStorage.getItem("sheets_config") || "{}") } catch { return { scriptUrl: "" } }
  })
  const [loading, setLoading] = useState(false)
  const [syncError, setSyncError] = useState("")
  const [modal, setModal] = useState<"add" | "settings" | "categories" | "profile" | null>(null)
  const [activeTab, setActiveTab] = useState<"dashboard" | "tabela">("dashboard")
  const [filterCategory, setFilterCategory] = useState("Todos")
  const [filterType, setFilterType] = useState("Todos")
  const [showUserMenu, setShowUserMenu] = useState(false)

  const isConnected = !!config.scriptUrl

  function refreshCategories() { setCategories(loadCategories()) }

  async function syncFromSheets() {
    if (!config.scriptUrl) return
    setLoading(true); setSyncError("")
    try { setExpenses(await fetchExpenses(config.scriptUrl)) }
    catch { setSyncError("Não foi possível conectar ao Google Sheets.") }
    finally { setLoading(false) }
  }

  useEffect(() => { if (isConnected) syncFromSheets() }, [config.scriptUrl])

  async function handleSaveExpense(expense: Omit<Expense, "id">) {
    const newExp: Expense = { ...expense, id: `local-${Date.now()}` }
    setExpenses((prev) => [newExp, ...prev])
    if (config.scriptUrl) await appendExpense(config.scriptUrl, expense)
  }

  function handleSaveConfig(c: SheetsConfig) {
    setConfig(c)
    localStorage.setItem("sheets_config", JSON.stringify(c))
  }

  // Period-filtered expenses
  const periodExpenses = useMemo(() =>
    expenses.filter((e) => e.data >= period.from && e.data <= period.to),
    [expenses, period]
  )

  const despesas = useMemo(() => periodExpenses.filter((e) => e.tipo === "Despesa"), [periodExpenses])
  const receitas = useMemo(() => periodExpenses.filter((e) => e.tipo === "Receita"), [periodExpenses])
  const totalDespesas = useMemo(() => despesas.reduce((s, e) => s + e.valor, 0), [despesas])
  const totalReceitas = useMemo(() => receitas.reduce((s, e) => s + e.valor, 0), [receitas])
  const saldo = totalReceitas - totalDespesas

  const categoryMap = useMemo(() => {
    const m: Record<string, string> = {}
    categories.forEach((c) => { m[c.name] = c.color })
    return m
  }, [categories])
  const emojiMap = useMemo(() => {
    const m: Record<string, string> = {}
    categories.forEach((c) => { m[c.name] = c.emoji })
    return m
  }, [categories])

  const categoryTotals = useMemo(() => {
    const map: Record<string, number> = {}
    despesas.forEach((e) => { map[e.categoria] = (map[e.categoria] ?? 0) + e.valor })
    return Object.entries(map).sort((a, b) => b[1] - a[1]).map(([name, total]) => ({ name, total, color: categoryMap[name] ?? "#64748b" }))
  }, [despesas, categoryMap])

  const topCategory = categoryTotals[0]

  const filtered = useMemo(() =>
    periodExpenses
      .filter((e) => filterCategory === "Todos" || e.categoria === filterCategory)
      .filter((e) => filterType === "Todos" || e.tipo === filterType)
      .sort((a, b) => b.data.localeCompare(a.data)),
    [periodExpenses, filterCategory, filterType]
  )

  const monthlyBar = useMemo(() => {
    const map: Record<string, { mes: string; despesa: number; receita: number }> = {}
    expenses.forEach((e) => {
      const key = e.data.slice(0, 7)
      if (!map[key]) map[key] = { mes: key, despesa: 0, receita: 0 }
      if (e.tipo === "Despesa") map[key].despesa += e.valor
      else map[key].receita += e.valor
    })
    return Object.values(map).sort((a, b) => a.mes.localeCompare(b.mes)).slice(-6).map((m) => ({
      ...m,
      mes: m.mes.slice(5) + "/" + m.mes.slice(2, 4),
    }))
  }, [expenses])

  const user = getUser()

  return (
    <div className="min-h-screen" style={{ background: "var(--background)", color: "var(--foreground)" }}>
      {/* ── Header ── */}
      <header className="sticky top-0 z-40 px-4 sm:px-6 py-3 flex items-center gap-3" style={{ background: "rgba(13,17,23,0.9)", backdropFilter: "blur(12px)", borderBottom: "1px solid var(--border)" }}>
        {/* Logo */}
        <div className="flex items-center gap-2.5 shrink-0">
          <div className="w-7 h-7 rounded-lg flex items-center justify-center" style={{ background: "linear-gradient(135deg, #10b981, #6366f1)" }}>
            <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><circle cx="7" cy="7" r="5.5" stroke="#fff" strokeWidth="1.3"/><path d="M7 4v1.5M7 8.5V10M5 7h4" stroke="#fff" strokeWidth="1.2" strokeLinecap="round"/></svg>
          </div>
          <span className="font-semibold text-sm hidden sm:inline">FinancesPro</span>
        </div>

        {/* Period selector - center */}
        <div className="flex-1 flex justify-center">
          <PeriodSelector period={period} onChange={setPeriod} />
        </div>

        {/* Actions */}
        <div className="flex items-center gap-1.5 shrink-0">
          <nav className="hidden md:flex items-center gap-1 rounded-xl p-1 mr-1" style={{ background: "var(--muted)" }}>
            {(["dashboard", "tabela"] as const).map((tab) => (
              <button key={tab} onClick={() => setActiveTab(tab)}
                className="px-3 py-1.5 rounded-lg text-xs font-medium transition-all"
                style={{ background: activeTab === tab ? "var(--card)" : "transparent", color: activeTab === tab ? "var(--foreground)" : "var(--muted-foreground)" }}>
                {tab === "dashboard" ? "Dashboard" : "Lançamentos"}
              </button>
            ))}
          </nav>

          {isConnected && (
            <button onClick={syncFromSheets} disabled={loading} className="w-8 h-8 flex items-center justify-center rounded-xl hover:bg-white/10 transition-colors" title="Sincronizar" style={{ opacity: loading ? 0.5 : 1 }}>
              <svg width="14" height="14" viewBox="0 0 14 14" fill="none" style={{ animation: loading ? "spin 1s linear infinite" : "none" }}>
                <path d="M1 7A6 6 0 0112 4M13 7A6 6 0 012 10" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round"/>
                <path d="M10 2l2 2-2 2M4 10l-2 2 2 2" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </button>
          )}

          <button onClick={() => setModal("settings")} className="w-8 h-8 flex items-center justify-center rounded-xl hover:bg-white/10 transition-colors" title="Google Sheets">
            <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><rect x="1.5" y="2" width="11" height="10" rx="1.5" stroke="currentColor" strokeWidth="1.3"/><path d="M5 5h4M5 7.5h4M5 10h2" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round"/></svg>
          </button>

          <button onClick={() => { setModal("categories"); refreshCategories() }} className="w-8 h-8 flex items-center justify-center rounded-xl hover:bg-white/10 transition-colors" title="Categorias">
            <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><rect x="1.5" y="1.5" width="4.5" height="4.5" rx="1" stroke="currentColor" strokeWidth="1.3"/><rect x="8" y="1.5" width="4.5" height="4.5" rx="1" stroke="currentColor" strokeWidth="1.3"/><rect x="1.5" y="8" width="4.5" height="4.5" rx="1" stroke="currentColor" strokeWidth="1.3"/><rect x="8" y="8" width="4.5" height="4.5" rx="1" stroke="currentColor" strokeWidth="1.3"/></svg>
          </button>

          <button onClick={() => setModal("add")}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-sm font-semibold hover:opacity-90 transition-opacity"
            style={{ background: "var(--primary)", color: "#fff" }}>
            <svg width="12" height="12" viewBox="0 0 12 12" fill="none"><path d="M6 1v10M1 6h10" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"/></svg>
            <span className="hidden sm:inline">Lançar</span>
          </button>

          {/* User avatar */}
          <div className="relative">
            <button onClick={() => setShowUserMenu(!showUserMenu)}
              className="w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold ml-1"
              style={{ background: "linear-gradient(135deg, #10b981, #6366f1)" }}>
              {user.email[0].toUpperCase()}
            </button>
            {showUserMenu && (
              <div className="absolute right-0 top-10 w-48 rounded-xl py-1.5" style={{ background: "var(--card)", border: "1px solid var(--border)", boxShadow: "0 8px 32px rgba(0,0,0,0.4)" }}>
                <div className="px-3 py-2 border-b" style={{ borderColor: "var(--border)" }}>
                  <p className="text-xs font-medium truncate">{user.email}</p>
                </div>
                <button onClick={() => { setModal("profile"); setShowUserMenu(false) }} className="w-full text-left px-3 py-2 text-sm hover:bg-white/10 transition-colors flex items-center gap-2">
                  <svg width="13" height="13" viewBox="0 0 13 13" fill="none"><circle cx="6.5" cy="4" r="2.5" stroke="currentColor" strokeWidth="1.2"/><path d="M1 12c0-3 2.5-4.5 5.5-4.5S12 9 12 12" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round"/></svg>
                  Minha conta
                </button>
                <button onClick={() => { onLogout(); setShowUserMenu(false) }} className="w-full text-left px-3 py-2 text-sm hover:bg-white/10 transition-colors flex items-center gap-2" style={{ color: "#f87171" }}>
                  <svg width="13" height="13" viewBox="0 0 13 13" fill="none"><path d="M5 2H2.5A1.5 1.5 0 001 3.5v6A1.5 1.5 0 002.5 11H5M9 9.5l2.5-3-2.5-3M11.5 6.5H5" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round"/></svg>
                  Sair
                </button>
              </div>
            )}
          </div>
        </div>
      </header>

      {/* Mobile nav */}
      <div className="md:hidden flex gap-1 px-4 pt-3">
        {(["dashboard", "tabela"] as const).map((tab) => (
          <button key={tab} onClick={() => setActiveTab(tab)}
            className="flex-1 py-2 rounded-xl text-sm font-medium"
            style={{ background: activeTab === tab ? "var(--card)" : "transparent", border: "1px solid var(--border)", color: activeTab === tab ? "var(--foreground)" : "var(--muted-foreground)" }}>
            {tab === "dashboard" ? "Dashboard" : "Lançamentos"}
          </button>
        ))}
      </div>

      {syncError && (
        <div className="mx-4 sm:mx-6 mt-3 rounded-xl px-4 py-3 text-sm flex items-center gap-2" style={{ background: "rgba(239,68,68,0.1)", border: "1px solid rgba(239,68,68,0.3)", color: "#fca5a5" }}>
          <svg width="13" height="13" viewBox="0 0 13 13" fill="none"><circle cx="6.5" cy="6.5" r="5.5" stroke="currentColor" strokeWidth="1.2"/><path d="M6.5 4v3M6.5 9v.5" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round"/></svg>
          {syncError}
        </div>
      )}

      <main className="p-4 sm:p-6 max-w-7xl mx-auto" onClick={() => showUserMenu && setShowUserMenu(false)}>
        {activeTab === "dashboard" && (
          <div className="flex flex-col gap-5">
            {!isConnected && (
              <div className="rounded-2xl px-5 py-4 flex items-center justify-between gap-4" style={{ background: "rgba(99,102,241,0.1)", border: "1px solid rgba(99,102,241,0.3)" }}>
                <div>
                  <p className="text-sm font-medium" style={{ color: "#a5b4fc" }}>Modo demonstração</p>
                  <p className="text-xs mt-0.5" style={{ color: "var(--muted-foreground)" }}>Configure o Google Sheets para salvar seus dados reais.</p>
                </div>
                <button onClick={() => setModal("settings")} className="shrink-0 px-4 py-2 rounded-xl text-xs font-semibold" style={{ background: "#6366f1", color: "#fff" }}>Conectar</button>
              </div>
            )}

            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
              <SummaryCard label="Saldo" value={fmt(saldo)} color={saldo >= 0 ? "#10b981" : "#ef4444"}
                icon={<svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M7 2a5 5 0 100 10A5 5 0 007 2zm0 2v1m0 4v1m-1.5-2.5h3" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round"/></svg>} />
              <SummaryCard label="Receitas" value={fmt(totalReceitas)} color="#10b981"
                icon={<svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M7 10V4m-2.5 3L7 4l2.5 3" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round"/></svg>} />
              <SummaryCard label="Despesas" value={fmt(totalDespesas)} color="#ef4444"
                icon={<svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M7 4v6m-2.5-3L7 10l2.5-3" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round"/></svg>} />
              <SummaryCard label="Maior gasto" value={topCategory ? topCategory.name : "—"} sub={topCategory ? fmt(topCategory.total) : undefined} color={topCategory ? (categoryMap[topCategory.name] ?? "#64748b") : "#64748b"}
                icon={<svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M2 10l2.5-2.5L7 10l2.5-3.5L12 10" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round"/></svg>} />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              <div className="rounded-2xl p-5" style={{ background: "var(--card)", border: "1px solid var(--border)" }}>
                <h3 className="text-sm font-semibold mb-4">Despesas por categoria</h3>
                {categoryTotals.length === 0 ? (
                  <p className="text-sm text-center py-8" style={{ color: "var(--muted-foreground)" }}>Nenhuma despesa no período</p>
                ) : (
                  <div className="flex flex-col sm:flex-row items-center gap-4">
                    <ResponsiveContainer width={180} height={180}>
                      <PieChart>
                        <Pie data={categoryTotals} dataKey="total" cx="50%" cy="50%" innerRadius={48} outerRadius={75} paddingAngle={3}>
                          {categoryTotals.map((e, i) => <Cell key={i} fill={e.color} strokeWidth={0} />)}
                        </Pie>
                        <Tooltip content={<CustomTooltip />} />
                      </PieChart>
                    </ResponsiveContainer>
                    <div className="flex flex-col gap-2 flex-1 min-w-0">
                      {categoryTotals.map((cat) => (
                        <div key={cat.name} className="flex items-center gap-2 text-xs">
                          <span className="w-2.5 h-2.5 rounded-sm shrink-0" style={{ background: cat.color }} />
                          <span className="flex-1 truncate" style={{ color: "var(--muted-foreground)" }}>{cat.name}</span>
                          <span className="mono font-medium shrink-0">{fmt(cat.total)}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              <div className="rounded-2xl p-5" style={{ background: "var(--card)", border: "1px solid var(--border)" }}>
                <h3 className="text-sm font-semibold mb-4">Evolução mensal</h3>
                <ResponsiveContainer width="100%" height={190}>
                  <BarChart data={monthlyBar} barSize={12} barGap={3}>
                    <XAxis dataKey="mes" tick={{ fontSize: 11, fill: "#8b949e" }} axisLine={false} tickLine={false} />
                    <YAxis tick={{ fontSize: 11, fill: "#8b949e" }} axisLine={false} tickLine={false} tickFormatter={(v) => `R$${(v / 1000).toFixed(0)}k`} />
                    <Tooltip content={<CustomTooltip />} cursor={{ fill: "rgba(255,255,255,0.04)" }} />
                    <Legend wrapperStyle={{ fontSize: 11, color: "#8b949e" }} />
                    <Bar dataKey="receita" name="Receita" fill="#10b981" radius={[4, 4, 0, 0]} />
                    <Bar dataKey="despesa" name="Despesa" fill="#ef4444" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div className="rounded-2xl p-5" style={{ background: "var(--card)", border: "1px solid var(--border)" }}>
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-sm font-semibold">Últimos lançamentos</h3>
                <button onClick={() => setActiveTab("tabela")} className="text-xs font-medium" style={{ color: "var(--primary)" }}>Ver todos →</button>
              </div>
              <div className="flex flex-col divide-y" style={{ borderColor: "var(--border)" }}>
                {periodExpenses.slice(0, 6).map((e) => (
                  <div key={e.id} className="flex items-center gap-3 py-3">
                    <div className="w-9 h-9 rounded-xl flex items-center justify-center shrink-0 text-base" style={{ background: `${categoryMap[e.categoria] ?? "#64748b"}22` }}>
                      {emojiMap[e.categoria] ?? "📦"}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{e.descricao}</p>
                      <p className="text-xs mt-0.5" style={{ color: "var(--muted-foreground)" }}>{e.categoria} · {fmtDate(e.data)}</p>
                    </div>
                    <p className="mono text-sm font-semibold shrink-0" style={{ color: e.tipo === "Receita" ? "#10b981" : "#ef4444" }}>
                      {e.tipo === "Receita" ? "+" : "-"}{fmt(e.valor)}
                    </p>
                  </div>
                ))}
                {periodExpenses.length === 0 && (
                  <p className="text-sm text-center py-6" style={{ color: "var(--muted-foreground)" }}>Nenhum lançamento no período</p>
                )}
              </div>
            </div>
          </div>
        )}

        {activeTab === "tabela" && (
          <div className="flex flex-col gap-4">
            <div className="flex flex-wrap items-center gap-3">
              <h2 className="text-base font-semibold flex-1">Lançamentos</h2>
              <select value={filterType} onChange={(e) => setFilterType(e.target.value)}
                className="px-3 py-2 rounded-xl text-sm outline-none"
                style={{ background: "var(--card)", border: "1px solid var(--border)", color: "var(--foreground)" }}>
                <option>Todos</option><option>Despesa</option><option>Receita</option>
              </select>
              <select value={filterCategory} onChange={(e) => setFilterCategory(e.target.value)}
                className="px-3 py-2 rounded-xl text-sm outline-none"
                style={{ background: "var(--card)", border: "1px solid var(--border)", color: "var(--foreground)" }}>
                <option>Todos</option>
                {categories.map((c) => <option key={c.id}>{c.name}</option>)}
                <option>Receita</option>
              </select>
            </div>

            <div className="rounded-2xl overflow-hidden" style={{ background: "var(--card)", border: "1px solid var(--border)" }}>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr style={{ borderBottom: "1px solid var(--border)" }}>
                      {["Data","Categoria","Descrição","Tipo","Valor"].map((h) => (
                        <th key={h} className="text-left px-4 py-3 text-xs font-medium uppercase tracking-wider" style={{ color: "var(--muted-foreground)" }}>{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {filtered.map((e, i) => (
                      <tr key={e.id} style={{ borderBottom: i < filtered.length - 1 ? "1px solid var(--border)" : "none" }} className="hover:bg-white/[0.03] transition-colors">
                        <td className="px-4 py-3 mono text-xs" style={{ color: "var(--muted-foreground)" }}>{fmtDate(e.data)}</td>
                        <td className="px-4 py-3">
                          <span className="inline-flex items-center gap-1.5 text-xs px-2.5 py-1 rounded-lg" style={{ background: `${categoryMap[e.categoria] ?? "#64748b"}22`, color: categoryMap[e.categoria] ?? "#64748b" }}>
                            {emojiMap[e.categoria] ?? "📦"} {e.categoria}
                          </span>
                        </td>
                        <td className="px-4 py-3 max-w-48 truncate">{e.descricao}</td>
                        <td className="px-4 py-3">
                          <span className="text-xs px-2 py-0.5 rounded-md font-medium" style={{ background: e.tipo === "Receita" ? "rgba(16,185,129,0.15)" : "rgba(239,68,68,0.15)", color: e.tipo === "Receita" ? "#10b981" : "#ef4444" }}>{e.tipo}</span>
                        </td>
                        <td className="px-4 py-3 mono font-semibold text-right" style={{ color: e.tipo === "Receita" ? "#10b981" : "#ef4444" }}>
                          {e.tipo === "Receita" ? "+" : "-"}{fmt(e.valor)}
                        </td>
                      </tr>
                    ))}
                    {filtered.length === 0 && (
                      <tr><td colSpan={5} className="px-4 py-10 text-center text-sm" style={{ color: "var(--muted-foreground)" }}>Nenhum lançamento encontrado</td></tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-2 px-1">
              <p className="text-xs" style={{ color: "var(--muted-foreground)" }}>{filtered.length} lançamentos</p>
              <div className="flex flex-wrap items-center gap-4 text-sm">
                <span>Despesas: <span className="mono font-semibold" style={{ color: "#ef4444" }}>{fmt(filtered.filter((e) => e.tipo === "Despesa").reduce((s, e) => s + e.valor, 0))}</span></span>
                <span>Receitas: <span className="mono font-semibold" style={{ color: "#10b981" }}>{fmt(filtered.filter((e) => e.tipo === "Receita").reduce((s, e) => s + e.valor, 0))}</span></span>
              </div>
            </div>
          </div>
        )}
      </main>

      {modal === "add" && <AddExpenseModal onClose={() => setModal(null)} onSave={handleSaveExpense} categories={categories} />}
      {modal === "settings" && <SettingsModal config={config} onSave={handleSaveConfig} onClose={() => setModal(null)} />}
      {modal === "categories" && <CategoryManager onClose={() => { setModal(null); refreshCategories() }} />}
      {modal === "profile" && <ProfileModal onClose={() => setModal(null)} />}

      <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
    </div>
  )
}
