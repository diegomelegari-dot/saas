import { useState } from "react"
import { login, getUser } from "../auth"

interface Props {
  onLogin: () => void
}

export default function LoginPage({ onLogin }: Props) {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [error, setError] = useState("")
  const [showPassword, setShowPassword] = useState(false)
  const [loading, setLoading] = useState(false)
  const [view, setView] = useState<"login" | "forgot">("login")
  const [forgotEmail, setForgotEmail] = useState("")
  const [forgotSent, setForgotSent] = useState(false)

  function handleLogin(e: React.FormEvent) {
    e.preventDefault()
    setError("")
    setLoading(true)
    setTimeout(() => {
      const ok = login(email.trim(), password)
      if (ok) {
        onLogin()
      } else {
        setError("E-mail ou senha incorretos.")
      }
      setLoading(false)
    }, 600)
  }

  function handleForgot(e: React.FormEvent) {
    e.preventDefault()
    const user = getUser()
    if (forgotEmail.trim().toLowerCase() === user.email.toLowerCase()) {
      setForgotSent(true)
    } else {
      setError("E-mail não encontrado.")
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4" style={{ background: "var(--background)" }}>
      {/* background decoration */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div style={{ position: "absolute", top: "-20%", left: "50%", transform: "translateX(-50%)", width: 600, height: 600, background: "radial-gradient(circle, rgba(99,102,241,0.12) 0%, transparent 70%)" }} />
        <div style={{ position: "absolute", bottom: "-10%", right: "10%", width: 400, height: 400, background: "radial-gradient(circle, rgba(16,185,129,0.08) 0%, transparent 70%)" }} />
      </div>

      <div className="relative w-full max-w-sm">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="w-14 h-14 rounded-2xl mx-auto mb-4 flex items-center justify-center" style={{ background: "linear-gradient(135deg, #10b981, #6366f1)" }}>
            <svg width="28" height="28" viewBox="0 0 28 28" fill="none">
              <path d="M14 4C8.477 4 4 8.477 4 14s4.477 10 10 10 10-4.477 10-10S19.523 4 14 4zm0 3v2m0 12v2M8 14h2m10 0h2" stroke="#fff" strokeWidth="1.8" strokeLinecap="round"/>
              <circle cx="14" cy="14" r="3" fill="#fff" fillOpacity=".3" stroke="#fff" strokeWidth="1.5"/>
            </svg>
          </div>
          <h1 className="text-2xl font-bold">FinancesPro</h1>
          <p className="text-sm mt-1" style={{ color: "var(--muted-foreground)" }}>
            {view === "login" ? "Entre na sua conta" : "Redefinir senha"}
          </p>
        </div>

        <div className="rounded-2xl p-6" style={{ background: "var(--card)", border: "1px solid var(--border)" }}>
          {view === "login" ? (
            <form onSubmit={handleLogin} className="flex flex-col gap-4">
              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-medium" style={{ color: "var(--muted-foreground)" }}>E-mail</label>
                <input
                  type="email"
                  placeholder="seu@email.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  autoComplete="email"
                  required
                  className="rounded-xl px-4 py-2.5 text-sm outline-none transition-all"
                  style={{ background: "var(--muted)", border: "1px solid var(--border)", color: "var(--foreground)" }}
                  onFocus={(e) => e.currentTarget.style.borderColor = "var(--primary)"}
                  onBlur={(e) => e.currentTarget.style.borderColor = "var(--border)"}
                />
              </div>

              <div className="flex flex-col gap-1.5">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-medium" style={{ color: "var(--muted-foreground)" }}>Senha</label>
                  <button type="button" onClick={() => setView("forgot")} className="text-xs font-medium" style={{ color: "var(--primary)" }}>
                    Esqueci a senha
                  </button>
                </div>
                <div className="relative">
                  <input
                    type={showPassword ? "text" : "password"}
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    autoComplete="current-password"
                    required
                    className="w-full rounded-xl px-4 py-2.5 text-sm outline-none pr-10"
                    style={{ background: "var(--muted)", border: "1px solid var(--border)", color: "var(--foreground)" }}
                    onFocus={(e) => e.currentTarget.style.borderColor = "var(--primary)"}
                    onBlur={(e) => e.currentTarget.style.borderColor = "var(--border)"}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2"
                    style={{ color: "var(--muted-foreground)" }}
                  >
                    {showPassword
                      ? <svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M1 8s2.5-5 7-5 7 5 7 5-2.5 5-7 5-7-5-7-5z" stroke="currentColor" strokeWidth="1.3"/><circle cx="8" cy="8" r="2" stroke="currentColor" strokeWidth="1.3"/><path d="M2 2l12 12" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round"/></svg>
                      : <svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M1 8s2.5-5 7-5 7 5 7 5-2.5 5-7 5-7-5-7-5z" stroke="currentColor" strokeWidth="1.3"/><circle cx="8" cy="8" r="2" stroke="currentColor" strokeWidth="1.3"/></svg>
                    }
                  </button>
                </div>
              </div>

              {error && (
                <p className="text-xs flex items-center gap-1.5" style={{ color: "#f87171" }}>
                  <svg width="13" height="13" viewBox="0 0 13 13" fill="none"><circle cx="6.5" cy="6.5" r="5.5" stroke="currentColor" strokeWidth="1.2"/><path d="M6.5 3.5v3.5M6.5 9v.5" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round"/></svg>
                  {error}
                </p>
              )}

              <button
                type="submit"
                disabled={loading}
                className="w-full py-2.5 rounded-xl text-sm font-semibold mt-1 transition-all"
                style={{ background: "var(--primary)", color: "#fff", opacity: loading ? 0.7 : 1 }}
              >
                {loading ? "Entrando..." : "Entrar"}
              </button>
            </form>
          ) : forgotSent ? (
            <div className="text-center flex flex-col gap-4">
              <div className="w-12 h-12 rounded-2xl mx-auto flex items-center justify-center" style={{ background: "rgba(16,185,129,0.15)" }}>
                <svg width="22" height="22" viewBox="0 0 22 22" fill="none"><path d="M4 11l5 5 9-9" stroke="#10b981" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>
              </div>
              <div>
                <p className="font-semibold">E-mail enviado!</p>
                <p className="text-sm mt-1" style={{ color: "var(--muted-foreground)" }}>
                  Verifique sua caixa de entrada em <span className="font-medium" style={{ color: "var(--foreground)" }}>{forgotEmail}</span> para redefinir sua senha.
                </p>
              </div>
              <button
                onClick={() => { setView("login"); setForgotSent(false); setError("") }}
                className="text-sm font-medium"
                style={{ color: "var(--primary)" }}
              >
                ← Voltar para o login
              </button>
            </div>
          ) : (
            <form onSubmit={handleForgot} className="flex flex-col gap-4">
              <p className="text-sm" style={{ color: "var(--muted-foreground)" }}>
                Digite seu e-mail e enviaremos um link para redefinir sua senha.
              </p>
              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-medium" style={{ color: "var(--muted-foreground)" }}>E-mail</label>
                <input
                  type="email"
                  placeholder="seu@email.com"
                  value={forgotEmail}
                  onChange={(e) => { setForgotEmail(e.target.value); setError("") }}
                  required
                  className="rounded-xl px-4 py-2.5 text-sm outline-none"
                  style={{ background: "var(--muted)", border: "1px solid var(--border)", color: "var(--foreground)" }}
                  onFocus={(e) => e.currentTarget.style.borderColor = "var(--primary)"}
                  onBlur={(e) => e.currentTarget.style.borderColor = "var(--border)"}
                />
              </div>
              {error && <p className="text-xs" style={{ color: "#f87171" }}>{error}</p>}
              <button
                type="submit"
                className="w-full py-2.5 rounded-xl text-sm font-semibold"
                style={{ background: "var(--primary)", color: "#fff" }}
              >
                Enviar link
              </button>
              <button
                type="button"
                onClick={() => { setView("login"); setError("") }}
                className="text-sm font-medium"
                style={{ color: "var(--muted-foreground)" }}
              >
                ← Voltar para o login
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  )
}
