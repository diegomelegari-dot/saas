export interface User {
  email: string
  password: string
}

const STORAGE_KEY = "finances_user"
const SESSION_KEY = "finances_session"

const DEFAULT_USER: User = {
  email: "xitaodih@gmail.com",
  password: "teste123",
}

export function initAuth() {
  if (!localStorage.getItem(STORAGE_KEY)) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(DEFAULT_USER))
  }
}

export function getUser(): User {
  initAuth()
  return JSON.parse(localStorage.getItem(STORAGE_KEY)!)
}

export function login(email: string, password: string): boolean {
  const user = getUser()
  if (email.trim().toLowerCase() === user.email.toLowerCase() && password === user.password) {
    localStorage.setItem(SESSION_KEY, JSON.stringify({ email: user.email }))
    return true
  }
  return false
}

export function logout() {
  localStorage.removeItem(SESSION_KEY)
}

export function isLoggedIn(): boolean {
  return !!localStorage.getItem(SESSION_KEY)
}

export function changeCredentials(newEmail: string, newPassword: string): void {
  const user = getUser()
  const updated: User = {
    email: newEmail || user.email,
    password: newPassword || user.password,
  }
  localStorage.setItem(STORAGE_KEY, JSON.stringify(updated))
  localStorage.setItem(SESSION_KEY, JSON.stringify({ email: updated.email }))
}
